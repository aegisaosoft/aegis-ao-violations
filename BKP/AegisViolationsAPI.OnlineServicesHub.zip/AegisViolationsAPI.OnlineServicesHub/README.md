# AegisViolationsAPI.OnlineServicesHub

Реализация `IAegisAPIFinder` и `IAegisAPIPayer` для порталов OnlineServicesHub (Duncan Solutions).

## Структура

```
AegisViolationsAPI.OnlineServicesHub/
├── AegisViolationsAPI.OnlineServicesHub.csproj
├── IAegisViolationCaller.cs           # Base interface
├── Finders/
│   ├── OnlineServicesHubFinder.cs     # HttpClient-based (быстрый)
│   └── OnlineServicesHubSeleniumFinder.cs  # Selenium-based (для JS)
└── Payers/
    └── OnlineServicesHubPayer.cs      # Оплата штрафов
```

## Установка

```bash
dotnet add package HtmlAgilityPack
dotnet add package Selenium.WebDriver
```

Для Selenium нужен Chrome браузер. ChromeDriver скачается автоматически.

## Использование

### Finder (поиск штрафов)

```csharp
// Вариант 1: HttpClient (попробуй первым - быстрее)
using var finder = new OnlineServicesHubFinder("philadelphia");
finder.Error += (s, e) => Console.WriteLine($"Error: {e.Message}");

var violations = await finder.Find("ABC1234", "PA");

foreach (var v in violations)
{
    Console.WriteLine($"{v.CitationNumber}: ${v.Amount} - {v.Note}");
}

// Вариант 2: Selenium (если HttpClient не работает)
using var seleniumFinder = new OnlineServicesHubSeleniumFinder("philadelphia", headless: true);
var violations = await seleniumFinder.Find("ABC1234", "PA");
```

### Payer (оплата)

```csharp
var card = new PaymentCard
{
    CardNumber = "4111111111111111",
    CardholderName = "JOHN DOE",
    ExpiryMonth = "12",
    ExpiryYear = "25",
    Cvv = "123",
    BillingZip = "19101"
};

using var payer = new OnlineServicesHubPayer(card, "philadelphia", headless: true);

// Простая оплата (bool)
bool success = await payer.Pay("12345678", 50.00m);

// Или с деталями
PaymentResult result = await payer.PayWithDetailsAsync("12345678", 50.00m);
if (result.Success)
{
    Console.WriteLine($"Paid! Confirmation: {result.ConfirmationNumber}");
}
else
{
    Console.WriteLine($"Failed: {result.ErrorMessage}");
}
```

## Регистрация в DI

```csharp
services.AddTransient<IAegisAPIFinder>(sp => 
    new OnlineServicesHubFinder("philadelphia"));

// Или с Selenium для JS-rendered страниц
services.AddTransient<IAegisAPIFinder>(sp => 
    new OnlineServicesHubSeleniumFinder("philadelphia", headless: true));
```

## Поддерживаемые порталы

| Город | Provider ID | URL |
|-------|-------------|-----|
| Philadelphia | 100 | onlineserviceshub.com/ParkingPortal/Philadelphia |

### Добавление нового города

В `OnlineServicesHubFinder.cs` и `OnlineServicesHubSeleniumFinder.cs`:

```csharp
private static readonly Dictionary<string, (string Url, int ProviderId)> KnownPortals = new()
{
    ["philadelphia"] = ("https://onlineserviceshub.com/ParkingPortal/Philadelphia", 100),
    ["newcity"] = ("https://onlineserviceshub.com/ParkingPortal/NewCity", 101),
};
```

## ParkingViolation Mapping

| Поле | Источник |
|------|----------|
| `CitationNumber` | Номер штрафа с сайта |
| `Tag` | License plate (входной параметр) |
| `State` | State (входной параметр) |
| `Provider` | Provider ID из KnownPortals |
| `Agency` | "Philadelphia Parking Authority" |
| `Address` | Location с сайта |
| `Amount` | Total due |
| `IssueDate` | Issue date |
| `Note` | Violation description |
| `Link` | URL портала |
| `Currency` | "USD" |
| `IsActive` | true |
| `FineType` | 1 (parking) |
| `PaymentStatus` | 0=unpaid, 1=paid, 2=disputed, 3=voided |

## Обработка ошибок

```csharp
finder.Error += (sender, args) =>
{
    logger.LogError(args.Exception, 
        "Finder {Finder} failed for {Plate} ({State}): {Message}",
        args.FinderName, args.LicensePlate, args.State, args.Message);
};
```

## HttpClient vs Selenium

| Критерий | HttpClient | Selenium |
|----------|------------|----------|
| Скорость | Быстро | Медленно |
| Ресурсы | Мало | Много (Chrome) |
| JS-rendered страницы | Нет | Да |
| Оплата | Нет | Да |

**Рекомендация:** Начни с `OnlineServicesHubFinder`. Если не работает — используй `OnlineServicesHubSeleniumFinder`.

## Правовые аспекты оплаты

Автоматическая оплата легальна при наличии в договоре аренды:

```
ПАРКОВОЧНЫЕ ШТРАФЫ: Арендатор уполномочивает Компанию оплачивать 
штрафы от его имени и списывать сумму штрафа плюс административный 
сбор с платёжного метода Арендатора.
```

⚠️ **Важно:** Для хранения карт используй токенизацию Stripe (PCI DSS compliance).
