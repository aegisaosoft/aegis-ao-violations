/*
 *
 * Copyright (c) 2025 Alexander Orlov.
 * 34 Middletown Ave Atlantic Highlands NJ 07716
 *
 * THIS SOFTWARE IS THE CONFIDENTIAL AND PROPRIETARY INFORMATION OF
 * Alexander Orlov. ("CONFIDENTIAL INFORMATION"). YOU SHALL NOT DISCLOSE
 * SUCH CONFIDENTIAL INFORMATION AND SHALL USE IT ONLY IN ACCORDANCE
 * WITH THE TERMS OF THE LICENSE AGREEMENT YOU ENTERED INTO WITH
 * Alexander Orlov.
 *
 * Author: Alexander Orlov
 *
 */

using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support.UI;

namespace AegisViolationsAPI.Payers;

/// <summary>
/// Payment information for citation payment
/// </summary>
public class PaymentCard
{
    public string CardNumber { get; set; } = string.Empty;
    public string ExpiryMonth { get; set; } = string.Empty; // MM
    public string ExpiryYear { get; set; } = string.Empty;  // YY or YYYY
    public string Cvv { get; set; } = string.Empty;
    public string CardholderName { get; set; } = string.Empty;
    public string BillingZip { get; set; } = string.Empty;
    public string? BillingAddress { get; set; }
    public string? BillingCity { get; set; }
    public string? BillingState { get; set; }
}

/// <summary>
/// Payment result
/// </summary>
public class PaymentResult
{
    public bool Success { get; set; }
    public string? ConfirmationNumber { get; set; }
    public string? ErrorMessage { get; set; }
    public decimal? AmountPaid { get; set; }
    public DateTime? PaymentDate { get; set; }
}

/// <summary>
/// Payer for OnlineServicesHub parking portals
/// IMPORTANT: Use only with proper customer authorization
/// </summary>
public class OnlineServicesHubPayer : IAegisAPIPayer, IDisposable
{
    private readonly string _baseUrl;
    private readonly string _city;
    private readonly bool _headless;
    private readonly PaymentCard _paymentCard;
    private IWebDriver? _driver;
    private bool _disposed;

    private static readonly Dictionary<string, string> KnownPortals = new()
    {
        ["philadelphia"] = "https://onlineserviceshub.com/ParkingPortal/Philadelphia",
    };

    /// <summary>
    /// Creates a new OnlineServicesHub payer
    /// </summary>
    /// <param name="paymentCard">Payment card details</param>
    /// <param name="city">City name</param>
    /// <param name="headless">Run browser in headless mode</param>
    public OnlineServicesHubPayer(PaymentCard paymentCard, string city = "philadelphia", bool headless = true)
    {
        _paymentCard = paymentCard ?? throw new ArgumentNullException(nameof(paymentCard));
        _city = city.ToLower();
        _headless = headless;

        if (!KnownPortals.TryGetValue(_city, out var url))
            throw new ArgumentException($"Unknown city: {city}");

        _baseUrl = url;
    }

    /// <inheritdoc />
    public async Task<bool> Pay(string citation, decimal amount)
    {
        var result = await PayWithDetailsAsync(citation, amount);
        return result.Success;
    }

    /// <summary>
    /// Pay citation and return detailed result
    /// </summary>
    public async Task<PaymentResult> PayWithDetailsAsync(string citation, decimal expectedAmount)
    {
        var result = new PaymentResult();

        try
        {
            EnsureDriverInitialized();

            // Navigate to portal
            _driver!.Navigate().GoToUrl(_baseUrl);
            WaitForPageLoad();
            AcceptTermsIfPresent();

            // Search for citation
            if (!SearchCitation(citation))
            {
                result.ErrorMessage = "Citation not found";
                return result;
            }

            // Verify amount matches (within tolerance)
            var displayedAmount = GetDisplayedAmount();
            if (displayedAmount.HasValue && Math.Abs(displayedAmount.Value - expectedAmount) > 0.01m)
            {
                result.ErrorMessage = $"Amount mismatch: expected {expectedAmount:C}, found {displayedAmount:C}";
                return result;
            }

            // Click pay button
            if (!ClickPayButton())
            {
                result.ErrorMessage = "Pay button not found";
                return result;
            }

            // Fill payment form
            FillPaymentForm();

            // Submit payment
            if (!SubmitPayment())
            {
                result.ErrorMessage = "Failed to submit payment";
                return result;
            }

            // Wait for confirmation
            var confirmation = WaitForConfirmation();
            
            if (!string.IsNullOrEmpty(confirmation))
            {
                result.Success = true;
                result.ConfirmationNumber = confirmation;
                result.AmountPaid = displayedAmount ?? expectedAmount;
                result.PaymentDate = DateTime.UtcNow;
            }
            else
            {
                // Check for error message
                result.ErrorMessage = GetErrorMessage() ?? "Payment may have failed - no confirmation received";
            }
        }
        catch (Exception ex)
        {
            result.ErrorMessage = ex.Message;
        }

        return await Task.FromResult(result);
    }

    private void EnsureDriverInitialized()
    {
        if (_driver != null) return;

        var options = new ChromeOptions();

        if (_headless)
        {
            options.AddArgument("--headless=new");
        }

        options.AddArgument("--no-sandbox");
        options.AddArgument("--disable-dev-shm-usage");
        options.AddArgument("--disable-gpu");
        options.AddArgument("--window-size=1920,1080");
        options.AddArgument("--user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36");

        _driver = new ChromeDriver(options);
        _driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(10);
        _driver.Manage().Timeouts().PageLoad = TimeSpan.FromSeconds(30);
    }

    private void WaitForPageLoad()
    {
        var wait = new WebDriverWait(_driver, TimeSpan.FromSeconds(30));
        wait.Until(d => ((IJavaScriptExecutor)d).ExecuteScript("return document.readyState").ToString() == "complete");
    }

    private void AcceptTermsIfPresent()
    {
        try
        {
            var checkbox = _driver!.FindElements(By.CssSelector("input[type='checkbox']")).FirstOrDefault();
            if (checkbox != null && checkbox.Displayed && !checkbox.Selected)
            {
                checkbox.Click();
                Thread.Sleep(500);

                var continueBtn = _driver.FindElements(By.XPath("//button[contains(text(),'Continue')] | //input[@value='Continue']"))
                    .FirstOrDefault(b => b.Displayed);

                continueBtn?.Click();
                Thread.Sleep(1000);
            }
        }
        catch
        {
            // Modal might not appear
        }
    }

    private bool SearchCitation(string citation)
    {
        try
        {
            // Select citation number search type
            var searchTypeSelect = _driver!.FindElements(By.CssSelector("select")).FirstOrDefault();
            if (searchTypeSelect != null)
            {
                var selectElement = new SelectElement(searchTypeSelect);
                try
                {
                    selectElement.SelectByText("Ticket/Citation Number");
                }
                catch
                {
                    selectElement.SelectByIndex(0);
                }
            }

            Thread.Sleep(500);

            // Enter citation number
            var inputField = _driver.FindElement(By.CssSelector("input[type='text']"));
            inputField.Clear();
            inputField.SendKeys(citation);

            // Click search
            var searchBtn = _driver.FindElement(By.XPath("//button[contains(text(),'Search')] | //input[@value='Search']"));
            searchBtn.Click();

            Thread.Sleep(2000);

            // Check if citation was found
            var pageSource = _driver.PageSource.ToLower();
            return !pageSource.Contains("not found") && !pageSource.Contains("no results") && !pageSource.Contains("no ticket");
        }
        catch
        {
            return false;
        }
    }

    private decimal? GetDisplayedAmount()
    {
        try
        {
            var pageSource = _driver!.PageSource;
            var amountMatch = System.Text.RegularExpressions.Regex.Match(
                pageSource, 
                @"(?:Total|Amount|Balance)[:\s]*\$?([\d,]+\.?\d*)", 
                System.Text.RegularExpressions.RegexOptions.IgnoreCase);

            if (amountMatch.Success && decimal.TryParse(amountMatch.Groups[1].Value.Replace(",", ""), out var amount))
                return amount;
        }
        catch
        {
        }

        return null;
    }

    private bool ClickPayButton()
    {
        try
        {
            var payButtons = _driver!.FindElements(By.XPath(
                "//button[contains(text(),'Pay')] | " +
                "//input[@value='Pay'] | " +
                "//a[contains(text(),'Pay')] | " +
                "//button[contains(@class,'pay')]"));

            var payButton = payButtons.FirstOrDefault(b => b.Displayed && b.Enabled);
            if (payButton == null) return false;

            payButton.Click();
            Thread.Sleep(2000);
            return true;
        }
        catch
        {
            return false;
        }
    }

    private void FillPaymentForm()
    {
        // Try to find and fill payment fields
        // Note: Field names vary by payment processor

        TryFillField(new[] { "cardNumber", "card_number", "cc_number", "ccnumber", "pan" }, _paymentCard.CardNumber);
        TryFillField(new[] { "cardholderName", "cardholder", "name_on_card", "ccname" }, _paymentCard.CardholderName);
        TryFillField(new[] { "expiryMonth", "exp_month", "ccmonth", "month" }, _paymentCard.ExpiryMonth);
        TryFillField(new[] { "expiryYear", "exp_year", "ccyear", "year" }, _paymentCard.ExpiryYear);
        TryFillField(new[] { "cvv", "cvc", "cvv2", "securityCode", "security_code" }, _paymentCard.Cvv);
        TryFillField(new[] { "billingZip", "zip", "postal", "zipcode", "billing_zip" }, _paymentCard.BillingZip);

        if (!string.IsNullOrEmpty(_paymentCard.BillingAddress))
            TryFillField(new[] { "address", "street", "billing_address", "address1" }, _paymentCard.BillingAddress);

        if (!string.IsNullOrEmpty(_paymentCard.BillingCity))
            TryFillField(new[] { "city", "billing_city" }, _paymentCard.BillingCity);

        if (!string.IsNullOrEmpty(_paymentCard.BillingState))
            TrySelectField(new[] { "state", "billing_state", "region" }, _paymentCard.BillingState);

        Thread.Sleep(500);
    }

    private void TryFillField(string[] possibleNames, string value)
    {
        foreach (var name in possibleNames)
        {
            try
            {
                // Try by name attribute
                var field = _driver!.FindElements(By.Name(name)).FirstOrDefault(f => f.Displayed);
                if (field != null)
                {
                    field.Clear();
                    field.SendKeys(value);
                    return;
                }

                // Try by id
                field = _driver.FindElements(By.Id(name)).FirstOrDefault(f => f.Displayed);
                if (field != null)
                {
                    field.Clear();
                    field.SendKeys(value);
                    return;
                }

                // Try by placeholder
                field = _driver.FindElements(By.CssSelector($"input[placeholder*='{name}' i]")).FirstOrDefault(f => f.Displayed);
                if (field != null)
                {
                    field.Clear();
                    field.SendKeys(value);
                    return;
                }
            }
            catch
            {
                // Continue to next name
            }
        }
    }

    private void TrySelectField(string[] possibleNames, string value)
    {
        foreach (var name in possibleNames)
        {
            try
            {
                var select = _driver!.FindElements(By.Name(name)).FirstOrDefault() ??
                            _driver.FindElements(By.Id(name)).FirstOrDefault();

                if (select != null && select.Displayed)
                {
                    var selectElement = new SelectElement(select);
                    try
                    {
                        selectElement.SelectByText(value);
                        return;
                    }
                    catch
                    {
                        try
                        {
                            selectElement.SelectByValue(value);
                            return;
                        }
                        catch
                        {
                        }
                    }
                }
            }
            catch
            {
            }
        }
    }

    private bool SubmitPayment()
    {
        try
        {
            var submitButtons = _driver!.FindElements(By.XPath(
                "//button[@type='submit'] | " +
                "//input[@type='submit'] | " +
                "//button[contains(text(),'Submit')] | " +
                "//button[contains(text(),'Pay Now')] | " +
                "//button[contains(text(),'Complete')]"));

            var submitButton = submitButtons.FirstOrDefault(b => b.Displayed && b.Enabled);
            if (submitButton == null) return false;

            submitButton.Click();

            // Wait for processing
            Thread.Sleep(5000);
            WaitForPageLoad();

            return true;
        }
        catch
        {
            return false;
        }
    }

    private string? WaitForConfirmation()
    {
        try
        {
            // Wait up to 30 seconds for confirmation
            var wait = new WebDriverWait(_driver, TimeSpan.FromSeconds(30));

            // Look for confirmation indicators
            wait.Until(d =>
            {
                var pageSource = d.PageSource.ToLower();
                return pageSource.Contains("confirmation") ||
                       pageSource.Contains("thank you") ||
                       pageSource.Contains("payment successful") ||
                       pageSource.Contains("receipt") ||
                       pageSource.Contains("error") ||
                       pageSource.Contains("declined");
            });

            var pageText = _driver!.PageSource;

            // Check for error first
            if (pageText.ToLower().Contains("declined") || pageText.ToLower().Contains("error"))
                return null;

            // Try to extract confirmation number
            var confirmMatch = System.Text.RegularExpressions.Regex.Match(
                pageText,
                @"(?:Confirmation|Receipt|Reference|Transaction)\s*(?:#|Number|ID)?[:\s]*([A-Z0-9\-]+)",
                System.Text.RegularExpressions.RegexOptions.IgnoreCase);

            return confirmMatch.Success ? confirmMatch.Groups[1].Value : "CONFIRMED";
        }
        catch
        {
            return null;
        }
    }

    private string? GetErrorMessage()
    {
        try
        {
            var errorElements = _driver!.FindElements(By.CssSelector(".error, .alert-danger, .error-message, [class*='error']"));
            var errorElement = errorElements.FirstOrDefault(e => e.Displayed && !string.IsNullOrWhiteSpace(e.Text));
            return errorElement?.Text;
        }
        catch
        {
            return null;
        }
    }

    /// <summary>
    /// Save screenshot for debugging
    /// </summary>
    public void SaveScreenshot(string filename)
    {
        if (_driver is ITakesScreenshot screenshotDriver)
        {
            var screenshot = screenshotDriver.GetScreenshot();
            screenshot.SaveAsFile(filename);
        }
    }

    /// <inheritdoc />
    public void Dispose()
    {
        if (_disposed) return;
        _driver?.Quit();
        _driver?.Dispose();
        _disposed = true;
    }
}
