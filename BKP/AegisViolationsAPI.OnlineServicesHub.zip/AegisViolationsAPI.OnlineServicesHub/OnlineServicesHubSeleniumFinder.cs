/*
 *
 * Copyright (c) 2025 Alexander Orlov.
 * 34 Middletown Ave Atlantic Highlands NJ 07716
 *
 * THIS SOFTWARE IS THE CONFIDENTIAL AND PROPRIETARY INFORMATION OF
 * Alexander Orlov. ("CONFIDENTIAL INFORMATION"). YOU SHALL NOT DISCLOSE
 * SUCH CONFIDENTIAL INFORMATION AND SHALL USE IT ONLY IN ACCORDANCE
 * WITH THE TERMS OF THE LICENSE AGREEMENT YOU ENTERED INTO WITH
 * Alexander Orlov.
 *
 * Author: Alexander Orlov
 *
 */

using System.Text.RegularExpressions;
using HuurApi.Models;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support.UI;

namespace AegisViolationsAPI.Finders;

/// <summary>
/// Selenium-based finder for OnlineServicesHub parking portals
/// Use when HttpClient approach fails (JavaScript-rendered content)
/// </summary>
public class OnlineServicesHubSeleniumFinder : IAegisAPIFinder, IDisposable
{
    private readonly string _baseUrl;
    private readonly string _city;
    private readonly int _providerId;
    private readonly bool _headless;
    private IWebDriver? _driver;
    private bool _disposed;

    private static readonly Dictionary<string, (string Url, int ProviderId)> KnownPortals = new()
    {
        ["philadelphia"] = ("https://onlineserviceshub.com/ParkingPortal/Philadelphia", OnlineServicesHubProvider.Philadelphia),
    };

    private static readonly Dictionary<string, string> StateMap = new()
    {
        ["AL"] = "Alabama", ["AK"] = "Alaska", ["AZ"] = "Arizona", ["AR"] = "Arkansas",
        ["CA"] = "California", ["CO"] = "Colorado", ["CT"] = "Connecticut", ["DE"] = "Delaware",
        ["DC"] = "District of Columbia", ["FL"] = "Florida", ["GA"] = "Georgia", ["HI"] = "Hawaii",
        ["ID"] = "Idaho", ["IL"] = "Illinois", ["IN"] = "Indiana", ["IA"] = "Iowa",
        ["KS"] = "Kansas", ["KY"] = "Kentucky", ["LA"] = "Louisiana", ["ME"] = "Maine",
        ["MD"] = "Maryland", ["MA"] = "Massachusetts", ["MI"] = "Michigan", ["MN"] = "Minnesota",
        ["MS"] = "Mississippi", ["MO"] = "Missouri", ["MT"] = "Montana", ["NE"] = "Nebraska",
        ["NV"] = "Nevada", ["NH"] = "New Hampshire", ["NJ"] = "New Jersey", ["NM"] = "New Mexico",
        ["NY"] = "New York", ["NC"] = "North Carolina", ["ND"] = "North Dakota", ["OH"] = "Ohio",
        ["OK"] = "Oklahoma", ["OR"] = "Oregon", ["PA"] = "Pennsylvania", ["RI"] = "Rhode Island",
        ["SC"] = "South Carolina", ["SD"] = "South Dakota", ["TN"] = "Tennessee", ["TX"] = "Texas",
        ["UT"] = "Utah", ["VT"] = "Vermont", ["VA"] = "Virginia", ["WA"] = "Washington",
        ["WV"] = "West Virginia", ["WI"] = "Wisconsin", ["WY"] = "Wyoming"
    };

    /// <inheritdoc />
    public string Link => _baseUrl;

    /// <inheritdoc />
    public event EventHandler<FinderErrorEventArgs>? Error;

    /// <summary>
    /// Creates a new Selenium-based OnlineServicesHub finder
    /// </summary>
    /// <param name="city">City name (e.g., "philadelphia")</param>
    /// <param name="headless">Run browser in headless mode</param>
    public OnlineServicesHubSeleniumFinder(string city = "philadelphia", bool headless = true)
    {
        _city = city.ToLower();
        _headless = headless;

        if (!KnownPortals.TryGetValue(_city, out var portalInfo))
            throw new ArgumentException($"Unknown city: {city}. Available: {string.Join(", ", KnownPortals.Keys)}");

        _baseUrl = portalInfo.Url;
        _providerId = portalInfo.ProviderId;
    }

    /// <inheritdoc />
    public async Task<List<ParkingViolation>> Find(string licensePlate, string state)
    {
        var violations = new List<ParkingViolation>();

        try
        {
            EnsureDriverInitialized();
            
            _driver!.Navigate().GoToUrl(_baseUrl);
            WaitForPageLoad();
            AcceptTermsIfPresent();

            // Find and select state dropdown
            SelectState(state);
            
            // Enter plate number
            EnterPlateNumber(licensePlate);
            
            // Click search
            ClickSearch();
            
            // Wait for results
            Thread.Sleep(2000);
            WaitForLoading();

            // Parse results
            violations = ParseResults(licensePlate, state);
        }
        catch (Exception ex)
        {
            OnError(licensePlate, state, ex);
        }

        return await Task.FromResult(violations);
    }

    private void EnsureDriverInitialized()
    {
        if (_driver != null) return;

        var options = new ChromeOptions();

        if (_headless)
        {
            options.AddArgument("--headless=new");
        }

        options.AddArgument("--no-sandbox");
        options.AddArgument("--disable-dev-shm-usage");
        options.AddArgument("--disable-gpu");
        options.AddArgument("--window-size=1920,1080");
        options.AddArgument("--user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36");
        options.AddUserProfilePreference("profile.managed_default_content_settings.images", 2);

        _driver = new ChromeDriver(options);
        _driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(10);
        _driver.Manage().Timeouts().PageLoad = TimeSpan.FromSeconds(30);
    }

    private void WaitForPageLoad()
    {
        var wait = new WebDriverWait(_driver, TimeSpan.FromSeconds(30));
        wait.Until(d => ((IJavaScriptExecutor)d).ExecuteScript("return document.readyState").ToString() == "complete");
    }

    private void AcceptTermsIfPresent()
    {
        try
        {
            var checkbox = _driver!.FindElements(By.CssSelector("input[type='checkbox']")).FirstOrDefault();
            if (checkbox != null && checkbox.Displayed && !checkbox.Selected)
            {
                checkbox.Click();
                Thread.Sleep(500);

                var continueBtn = _driver.FindElements(By.XPath("//button[contains(text(),'Continue')] | //input[@value='Continue']"))
                    .FirstOrDefault(b => b.Displayed);

                continueBtn?.Click();
                Thread.Sleep(1000);
            }
        }
        catch
        {
            // Modal might not appear
        }
    }

    private void SelectState(string state)
    {
        var stateSelects = _driver!.FindElements(By.CssSelector("select"));
        
        foreach (var select in stateSelects)
        {
            var options = select.FindElements(By.TagName("option"));
            if (options.Any(o => o.Text.Contains("Pennsylvania") || o.Text.Contains("PA")))
            {
                var selectElement = new SelectElement(select);
                var stateName = StateMap.GetValueOrDefault(state.ToUpper(), state);

                try
                {
                    selectElement.SelectByText(stateName);
                }
                catch
                {
                    try
                    {
                        selectElement.SelectByValue(state);
                    }
                    catch
                    {
                        // State not found
                    }
                }
                break;
            }
        }

        Thread.Sleep(500);
    }

    private void EnterPlateNumber(string licensePlate)
    {
        var inputFields = _driver!.FindElements(By.CssSelector("input[type='text']"));
        IWebElement? plateInput = null;

        // Try to find by placeholder or name
        foreach (var input in inputFields)
        {
            var placeholder = input.GetAttribute("placeholder")?.ToLower() ?? "";
            var name = input.GetAttribute("name")?.ToLower() ?? "";

            if (placeholder.Contains("plate") || name.Contains("plate"))
            {
                plateInput = input;
                break;
            }
        }

        // Fallback to last text input
        plateInput ??= inputFields.LastOrDefault();

        if (plateInput != null)
        {
            plateInput.Clear();
            plateInput.SendKeys(licensePlate);
        }
    }

    private void ClickSearch()
    {
        var searchBtns = _driver!.FindElements(By.XPath("//button[contains(text(),'Search')] | //input[@value='Search']"));
        var searchBtn = searchBtns.LastOrDefault(b => b.Displayed);
        searchBtn?.Click();
    }

    private void WaitForLoading()
    {
        try
        {
            var wait = new WebDriverWait(_driver, TimeSpan.FromSeconds(10));
            wait.Until(d =>
            {
                var loadingElements = d.FindElements(By.CssSelector(".loading, .spinner, [class*='load']"));
                return loadingElements.All(e => !e.Displayed);
            });
        }
        catch
        {
            // Timeout is fine
        }
    }

    private List<ParkingViolation> ParseResults(string licensePlate, string state)
    {
        var violations = new List<ParkingViolation>();
        var pageSource = _driver!.PageSource;

        // Try to find results in table
        var rows = _driver.FindElements(By.CssSelector("table tr, .ticket-row, .citation-item"));

        foreach (var row in rows.Skip(1)) // Skip header
        {
            try
            {
                var cells = row.FindElements(By.CssSelector("td"));
                if (cells.Count < 2) continue;

                var citationNum = cells[0].Text.Trim();
                if (string.IsNullOrEmpty(citationNum) || citationNum.ToLower().Contains("citation"))
                    continue;

                var violation = new ParkingViolation
                {
                    CitationNumber = citationNum,
                    Tag = licensePlate,
                    State = state,
                    Provider = _providerId,
                    Agency = GetAgencyName(),
                    Link = _baseUrl,
                    Currency = "USD",
                    IsActive = true,
                    FineType = 1
                };

                // Try to get amount from last cell
                var lastCellText = cells[cells.Count - 1].Text;
                var amountMatch = Regex.Match(lastCellText, @"\$?([\d,]+\.?\d*)");
                if (amountMatch.Success && decimal.TryParse(amountMatch.Groups[1].Value.Replace(",", ""), out var amount))
                    violation.Amount = amount;

                violations.Add(violation);
            }
            catch
            {
                // Skip problematic rows
            }
        }

        // If no table results, try regex on page source
        if (violations.Count == 0)
        {
            var violation = ParseSingleViolationFromHtml(pageSource, licensePlate, state);
            if (violation != null)
                violations.Add(violation);
        }

        return violations;
    }

    private ParkingViolation? ParseSingleViolationFromHtml(string html, string licensePlate, string state)
    {
        var citationMatch = Regex.Match(html, @"(?:Citation|Ticket)\s*(?:#|Number)?[:\s]*([A-Z0-9\-]+)", RegexOptions.IgnoreCase);
        if (!citationMatch.Success)
            return null;

        var violation = new ParkingViolation
        {
            CitationNumber = citationMatch.Groups[1].Value.Trim(),
            Tag = licensePlate,
            State = state,
            Provider = _providerId,
            Agency = GetAgencyName(),
            Link = _baseUrl,
            Currency = "USD",
            IsActive = true,
            FineType = 1
        };

        var totalMatch = Regex.Match(html, @"(?:Total|Amount)\s*(?:Due)?[:\s]*\$?([\d,]+\.?\d*)", RegexOptions.IgnoreCase);
        if (totalMatch.Success && decimal.TryParse(totalMatch.Groups[1].Value.Replace(",", ""), out var total))
            violation.Amount = total;

        var dateMatch = Regex.Match(html, @"(?:Issue|Violation)\s*Date[:\s]*([\d/\-]+)", RegexOptions.IgnoreCase);
        if (dateMatch.Success && DateTime.TryParse(dateMatch.Groups[1].Value, out var issueDate))
            violation.IssueDate = issueDate;

        var locMatch = Regex.Match(html, @"(?:Location|Address)[:\s]*([^\n<]+)", RegexOptions.IgnoreCase);
        if (locMatch.Success)
            violation.Address = locMatch.Groups[1].Value.Trim();

        var violMatch = Regex.Match(html, @"(?:Violation|Description)[:\s]*([^\n<]+)", RegexOptions.IgnoreCase);
        if (violMatch.Success)
            violation.Note = violMatch.Groups[1].Value.Trim();

        return violation;
    }

    private string GetAgencyName()
    {
        return _city.ToLower() switch
        {
            "philadelphia" => "Philadelphia Parking Authority",
            _ => $"OnlineServicesHub - {_city}"
        };
    }

    private void OnError(string licensePlate, string state, Exception ex)
    {
        Error?.Invoke(this, new FinderErrorEventArgs
        {
            FinderName = nameof(OnlineServicesHubSeleniumFinder),
            LicensePlate = licensePlate,
            State = state,
            Exception = ex,
            Message = ex.Message
        });
    }

    /// <summary>
    /// Save screenshot for debugging
    /// </summary>
    public void SaveScreenshot(string filename)
    {
        if (_driver is ITakesScreenshot screenshotDriver)
        {
            var screenshot = screenshotDriver.GetScreenshot();
            screenshot.SaveAsFile(filename);
        }
    }

    /// <inheritdoc />
    public void Dispose()
    {
        if (_disposed) return;
        _driver?.Quit();
        _driver?.Dispose();
        _disposed = true;
    }
}
